# Ethical
A python library to assist in writing ethical python code.
